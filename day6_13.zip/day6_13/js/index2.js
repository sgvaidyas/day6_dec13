/*function setfun()
{
    arr = document.getElementsByClassName('students');
    alert(arr)
    console.log(arr)
    console.log(arr.length)

}
var el = document.querySelector("#studmgmt > ul > li");
el.onclick = function what_to_do(){
var theText = this.innerHTML;
alert(theText);
}
*/
var allStuds = new Set()
var studs = new Set();
function setfun(){    
    this.addEventListener('click',(e)=>{
            if(e.target.classList.contains("students"))
            {
                //console.log(e.target.textContent);
                e.target.style.color = "white";
                e.target.style.background ="maroon"
                student = e.target.textContent;
                studs.add(student);
            }            
        })
}

function cal()
{
    getstu();
    absentees = Array.from(studs).join(", ")
    document.getElementById("abs").innerHTML = "Absentees = " +absentees
    document.getElementById("tot").innerHTML = allStuds.size
}

function getstu()
{
    const boxes = document.getElementsByClassName('students');
    for (let i = 0; i < boxes.length; i++) {        
        allStuds.add(boxes[i].id);
    }
    console.log(allStuds);
}